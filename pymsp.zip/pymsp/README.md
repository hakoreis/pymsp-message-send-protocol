Packages:

	pymsp/__init__.py
	pymsp/bath.py
	pymsp/combination.py
	pymsp/entrance.py
	pymsp/exceptions.py
	pymsp/handler.py
	pymsp/message_text.py
	pymsp/options.py
	pymsp/server.py
	
this module is the MSP (Message Send Protocol)

examples will come soon

this module was made for QPython but has an environment that can also be run from the computer

youtube_url : https://m.youtube.com/channel/UC_6Ir3R37th1dPS5NVzW6Vw?itct=CBkQ6p4EIhMIxqS24o3E4wIVrJfeCh1WBAZm&csn=zVozXfXXKcqdgAflvoToBQ&wlfg=true

Subscribe to youtube channel soon I will teach you how to use

