__author__ = "Software Hakan Vergil <hakanvergil@gmail.com>"
__copyright__ = "Copyright (C) 2018-2019 MSP (Message Send Protocol)"
__license__ = "Public Domain"
__version__ = "1.0"



