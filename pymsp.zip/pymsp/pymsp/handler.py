__copyright__ = """
Copyright (C) 2018-2019
MSP (Message Send Protocol)
Final"""

import options

if(__name__ == '__main__'):
    options.MSPMain()


